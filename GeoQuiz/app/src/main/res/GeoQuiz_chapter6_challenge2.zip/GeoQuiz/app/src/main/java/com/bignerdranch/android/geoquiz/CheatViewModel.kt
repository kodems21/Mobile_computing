package com.bignerdranch.android.geoquiz

import androidx.lifecycle.ViewModel

class CheatViewModel : ViewModel() {

    var hasCheated = false
}