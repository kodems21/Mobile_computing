package com.bignerdranch.android.geoquiz

class CheatViewModel {
}